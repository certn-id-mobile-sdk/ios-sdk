//
//  CertnIDMobileSDK.h
//  CertnIDMobileSDK
//
//  Created by Yuri Grigoriev on 25/06/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for CertnIDMobileSDK.
FOUNDATION_EXPORT double CertnIDMobileSDKVersionNumber;

//! Project version string for CertnIDMobileSDK.
FOUNDATION_EXPORT const unsigned char CertnIDMobileSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CertnIDMobileSDK/PublicHeader.h>


